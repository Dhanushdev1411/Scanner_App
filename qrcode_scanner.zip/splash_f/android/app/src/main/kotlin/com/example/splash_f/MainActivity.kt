package com.example.splash_f

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
